# -*- coding: utf-8 -*-

from tkinter import *
from tkinter import ttk

class GUIApp:

    def __init__(self, master):

        self._areaLabel = ttk.Label(master, text = "Area = ")
        self._hLabel = ttk.Label(master, text = "Thickness = ")
        self._poroLabel = ttk.Label(master, text = "Porosity = ")
        self._SwiLabel = ttk.Label(master, text = "Water Saturation = ")
        self._BoiLabel = ttk.Label(master, text = "Formation Volume Factor = ")
        self._stoiipLabel = ttk.Label(master, text = "STOIIP = ")
        
        self._areaEntry = ttk.Entry(master)
        self._hEntry = ttk.Entry(master)
        self._poroEntry = ttk.Entry(master)
        self._SwiEntry = ttk.Entry(master)
        self._BoiEntry = ttk.Entry(master)
        self._stoiipVal = ttk.Label(master)
        
        self._areaUnitLabel = ttk.Label(master, text = "acres ")
        self._hUnitLabel = ttk.Label(master, text = "ft ")
        self._poroUnitLabel = ttk.Label(master, text = "fraction ")
        self._SwiUnitLabel = ttk.Label(master, text = "fraction ")
        self._BoiUnitLabel = ttk.Label(master, text = "rb/stb ")
        self._stoiipUnitLabel = ttk.Label(master, text = "stb ")

        self._areaLabel.grid(row = 0, column = 0)
        self._hLabel.grid(row = 1, column = 0)
        self._poroLabel.grid(row = 2, column = 0)
        self._SwiLabel.grid(row = 3, column = 0)
        self._BoiLabel.grid(row = 4, column = 0)
        self._stoiipLabel.grid(row = 5, column = 0)
        
        self._areaEntry.grid(row = 0, column = 1)
        self._hEntry.grid(row = 1, column = 1)
        self._poroEntry.grid(row = 2, column = 1)
        self._SwiEntry.grid(row = 3, column = 1)
        self._BoiEntry.grid(row = 4, column = 1)
        self._stoiipVal.grid(row = 5, column = 1)
        
        self._areaUnitLabel.grid(row = 0, column = 2)
        self._hUnitLabel.grid(row = 1, column = 2)
        self._poroUnitLabel.grid(row = 2, column = 2)
        self._SwiUnitLabel.grid(row = 3, column = 2)
        self._BoiUnitLabel.grid(row = 4, column = 2)
        self._stoiipUnitLabel.grid(row = 5, column = 2)
        
        ttk.Button(master, text = "Compute STOIIP",
                   command = self.computeStoiip).grid(row = 6, column = 1)


    def computeStoiip(self):
        self._area = float(self._areaEntry.get()) 
        self._h = float(self._hEntry.get()) 
        self._poro = float(self._poroEntry.get()) 
        self._Swi = float(self._SwiEntry.get())
        self._Boi = float(self._BoiEntry.get())
        
        self._stoiip = 7758*self._area*self._h*self._poro*(1-self._Swi)/self._Boi
        
        self._stoiipVal.config(text = f'{self._stoiip}')

            
def main():            
    
    root = Tk()
    app = GUIApp(root)
    root.mainloop()
    
if __name__ == "__main__": main()
